/**
 * Data Table
 */
import React from 'react';
import { connect } from 'react-redux'; // to connect the component as part of mapStateToProps
import { withRouter } from 'react-router-dom'; //will pass updated props to the wrapped component 

import IconButton from '@material-ui/core/IconButton';
//axios call
import axios from 'axios';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';
import NumberClass from 'Util/NumberClass';

//Reloadable card
import {WatchesWidget} from "Components/Widgets";

//Bootstrap datatable custom cell style
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import ToolkitProvider, { Search } from 'react-bootstrap-table2-toolkit';

// For Tab
import Paper from '@material-ui/core/Paper';

import Spinner from 'Util/Spinner';


import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import NoSsr from '@material-ui/core/NoSsr';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';



function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

function LinkTab(props) {
  return <Tab component="a" onClick={event => event.preventDefault()} {...props} />;
}

 const styles = theme => ({
  customTab: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
});  

class ZonalNStationDtls extends React.Component {

		 
		  
		state = {
			value: this.props.match.params.operationStatus
		};

		handleChange = (event, value) => {
			if (typeof value != "string"){
				return;
			}
			this.setState({ value });
		};
			
		render() {
		
		const productsPicking = [ 
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Picking", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Picking", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Picking", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" }
		];
		
		const productsCnsolidtng = [ 
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Consolidating", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Consolidating", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Consolidating", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" }
		];
		
		const productsDcntng = [ 
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Decanting", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Decanting", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc Decanting", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" }
		];
		
		
		const productsCyclkCnt = [ 
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc CyclicCount", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc CyclicCount", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" },
			{stationName: "Station A", stationStatus: "Active", stnOvrlRunTime: "22 hrs", utilization: 85, operatorName: "Abc CyclicCount", runTime: "21 hrs", taskUnit: 2000, throughput: 1800, productivity: 80, exceptionType: "Medium" }
		];
	
		
		const columns = [
			{
				dataField: 'id',
				text: '',
				sort: true
			},
			{
				dataField: 'stationName',
				text: 'Station Name',
				align: 'center',
				sort: true
			},
			{
				dataField: 'stationStatus',
				text: 'Station Status',
				align: 'center',
				sort: true
			},
			{
				dataField: 'stnOvrlRunTime',
				text: 'Station Overall Run Time',
				sort: true
			},
			{
				dataField: 'utilization',
				text: 'Utilization',
				sort: true
			},
			{
				dataField: 'operatorName',
				text: 'Operator Name',
				sort: true
			},
			{
				dataField: 'runTime',
				text: 'Run Time',
				sort: true
			},
			{
				dataField: 'taskUnit',
				text: 'Task/Units',
				sort: true
			},
			{
				dataField: 'throughput',
				text: 'Throughput',
				sort: true
			},
			{
				dataField: 'productivity',
				text: 'Productivity',
				sort: true
			},
			{
				dataField: 'exceptionType',
				text: 'Exception Type',
				sort: true
			}
		];
		
    	const { value } = this.state;
		const labels = ["Picking", "Consolidation", "Decanting", "Cycle Count"];
		return(
			
		 <NoSsr>
        <div className={"customTab"}>
			<AppBar position="static" className="customAppBar" style={{fontColor: '#647C72', backgroundColor: '#647C72'}}>
				<Tabs value={value} onChange={this.handleChange} className="customAppBar" >
				{labels && labels.map((label, key) => (
					<Tab style={{textTransform: 'uppercase'}} value={label} label={label} />
				))}
				</Tabs>
			</AppBar>
          	{value === "Picking" && <TabContainer>
				<RctCard>
					<RctCardContent>
				
							<div>								
								<BootstrapTable
								keyField="id"
								data={ productsPicking } 
								columns={ columns } 
								bordered={ false }
								striped
								hover
								condensed
								/>
							</div>
							
					</RctCardContent>
				</RctCard >
		  </TabContainer>}
          {value === "Consolidation" && <TabContainer>
				<RctCard>
					<RctCardContent>
				
							<div>								
								<BootstrapTable
								keyField="id"
								data={ productsCnsolidtng } 
								columns={ columns } 
								bordered={ false }
								striped
								hover
								condensed
								/>
							</div>
							
					</RctCardContent>
				</RctCard >
		  </TabContainer>}
          {value === "Decanting" && <TabContainer>
				<RctCard>
					<RctCardContent>
				
							<div>								
								<BootstrapTable
								keyField="id"
								data={ productsDcntng } 
								columns={ columns } 
								bordered={ false }
								striped
								hover
								condensed
								/>
							</div>
							
					</RctCardContent>
				</RctCard >
		  </TabContainer>}
          {value === "Cycle Count" && <TabContainer>
				<RctCard>
					<RctCardContent>
				
							<div>								
								<BootstrapTable
								keyField="id"
								data={ productsCyclkCnt } 
								columns={ columns } 
								bordered={ false }
								striped
								hover
								condensed
								/>
							</div>
							
					</RctCardContent>
				</RctCard >
		  </TabContainer>}
        </div>
      </NoSsr> 
		
			
			);
		}
}

export default ZonalNStationDtls;

