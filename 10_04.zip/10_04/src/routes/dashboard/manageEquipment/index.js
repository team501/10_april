/**
 * Manage Equipment
 */

import React, { Component } from 'react';

//Reloadable card
import {InductsForTheDayWidget,
		WaveStatusWidget,
		InductsForTheLastHourWidget,
		SortsForTheDayWidget,
		SortsForTheLastHourWidget,
		SortersWidget} from "Components/Widgets";

// intl messages
import IntlMessages from 'Util/IntlMessages';

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

//json
import json from 'JsnCnfg/MngEqpmnt/UntSrtrMnDshbrd/goalDetails.json';

export default class EcommerceDashboard extends Component {

	constructor(props) {
		super(props);
		this.state = { currentTime: {} };
	}
	
	//Starting cyclic-refresh. 
	async componentDidMount() {		
	    this.intervalID = setInterval( () => this.timeGenrator(), localStorage.getItem("refreshInterval") );
	}
	
	/*Refresh callback function,
	 *responsible for generating time as props for child elements.*/
	async timeGenrator() {
		console.log(".....................................");
		this.setState({ currentTime: new Date().getTime() });
	}
	
	//Clearing previous interval on component unmount.
	componentWillUnmount() {
	    clearInterval(this.intervalID);
	}

   render() {
	  const { match } = this.props;
	  
	  const sorterDetails = json.container.component.goalDetails;
	
			  
	  let goals = sorterDetails.reduce((a, b) => ({ inductGoalPerDay: a.inductGoalPerDay + b.inductGoalPerDay ,
												   	inductGoalPerHour: a.inductGoalPerHour + b.inductGoalPerHour,
												   	sortsGoalPerDay: a.sortsGoalPerDay + b.sortsGoalPerDay,
												   	sortsGoalPerHour: a.sortsGoalPerHour + b.sortsGoalPerHour }) ); 
	  
	  let sorterLevelGoals = sorterDetails.map(element => ({name: element.name, sortsGoalPerHour: element.sortsGoalPerHour, inductGoalPerHour: element.inductGoalPerHour}));
	  	  
      return (
         <div className="ecom-dashboard-wrapper">
            <PageTitleBar title={<IntlMessages id="unitsorterDashbrd.title" />} arrowRequired={false} match={match} />
            <div className="row row-no-margin">
            	<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 col-class-left unisotter">
					{/*Passing sorterid for sorter id, goal for Goal Values  and current time.*/}
					<div class="clearboth"></div>
					<InductsForTheDayWidget currentTime={this.state.currentTime} sorterid="" goal={goals.inductGoalPerDay}/><div class="clearboth"></div>
					<InductsForTheLastHourWidget currentTime={this.state.currentTime} sorterid="" goal={goals.inductGoalPerHour}/><div class="clearboth"></div>
					<SortsForTheDayWidget currentTime={this.state.currentTime} sorterid="" goal={goals.sortsGoalPerDay}/><div class="clearboth"></div>
					<SortsForTheLastHourWidget currentTime={this.state.currentTime} sorterid="" goal={goals.sortsGoalPerHour}/><div class="clearboth"></div>
            	</div>
            	<div className="col-sm-8 col-md-8 col-lg-8 col-xl-8 col-class-right">
					<WaveStatusWidget currentTime={this.state.currentTime} />
					<SortersWidget currentTime={this.state.currentTime} goal={sorterLevelGoals}/>
            	</div>
            </div>
         </div>
      )
   }
}
