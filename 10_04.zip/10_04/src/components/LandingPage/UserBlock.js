/**
 * User Block Component
 */
import React, { Component } from 'react';
import { Dropdown, DropdownToggle, DropdownMenu } from 'reactstrap';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
//import { Badge } from 'reactstrap';
import { NotificationManager } from 'react-notifications';
import Tooltip from '@material-ui/core/Tooltip';

// components
//import SupportPage from '../Support/Support';

// redux action
import { logoutUserFromFirebase } from 'Actions';

// intl messages
import IntlMessages from 'Util/IntlMessages';

class UserBlock extends Component {

	state = {
		userDropdownMenu: false,
		isSupportModal: false
	}

	/**
	 * Logout User
	 */
	logoutUser() {
		this.props.logoutUserFromFirebase();
	}

	/**
	 * Toggle User Dropdown Menu
	 */
	toggleUserDropdownMenu() {
		this.setState({ userDropdownMenu: !this.state.userDropdownMenu });
	}


	render() {
		return (
                <Dropdown
                    isOpen={this.state.userDropdownMenu}
                    toggle={() => this.toggleUserDropdownMenu()}
                    className="rct-dropdown"
                >
                    <DropdownToggle 
                        tag="div"
                        className="d-flex align-items-center"
                    >
					<Tooltip title={<IntlMessages id="LandingPage.User" />} placement="bottom">
                        <div className="user-profile">
                            <a href="javascript:void(0)" className="header-icon tour-step-3">
									<i className="zmdi zmdi-account-circle"></i>
								</a>
                        </div>
						</Tooltip>
                    </DropdownToggle>
                    <DropdownMenu className="logout-menu">
                        <ul className="list-unstyled mb-0">
                            <li className="border-top">
                                <a href="javascript:void(0)" onClick={() => this.logoutUser()}>
                                    <i className="zmdi zmdi-power text-danger mr-3"></i>
                                    <IntlMessages id="LandingPage.logOut" />
                                </a>
                            </li>
                        </ul>
                    </DropdownMenu>
                </Dropdown>
		);
	}
}

// map state to props
const mapStateToProps = ({ settings }) => {
	return settings;
}

export default connect(mapStateToProps, {
	logoutUserFromFirebase
})(UserBlock);
