/**
 * @fileOverview LegendItem component.
 * Rendered SVG box, label, and percent for each item.
 * @name LegendItem.js
 * @license MIT
 */
import React, { Component } from 'react';
import PropTypes from 'prop-types';

// intl messages
import IntlMessages from 'Util/IntlMessages';

/**
 * @extends {Component}
 */
export default class LegendItem extends Component {
    /* React render function */
    render() {
        const {
            className, item, index, onClick, onMouseEnter, fill, opacity,
            width, totalWidth, stroke
        } = this.props;
        const { label, percent, value } = item;

        const legendRectClassName = `${className}-rect`;
        const legendLabelClassName = `${className}-label`;
        const sqUnit = width / 10;
        const yOffset = 1.6;

        const position = `translate(${totalWidth - width  + 75}, ${((index * yOffset) * sqUnit) + 40})`;
        return <g
            transform={ position }
            className= { className }
            onClick={ () => { onClick(item); } }
            onMouseEnter={ () => { onMouseEnter(item); } }>
            <rect
                className={ legendRectClassName }
                width={ sqUnit }
                height={ sqUnit }
                fill={ fill }
				x={ (sqUnit / 6) }
                y= { sqUnit / 2 }
                opacity={ opacity }
                stroke={ stroke }>
            </rect>
            <text
                className={ legendLabelClassName }
                fontSize= "large"
                x={ 1.2 * sqUnit + (sqUnit / 2) }
                y= { sqUnit}
                dy=".35em">
                {<IntlMessages id={`donutChart.${label}`} />}
            </text>
            <text
                className={ legendLabelClassName }
                fontSize= "x-large"
                fontWeight= '600'
                x={ 5.7 * sqUnit + (sqUnit / 2) }
                y= { sqUnit}
                dy=".35em">
                { `${value} - ${percent}%`}
            </text>
            <line x1={width} y1={width * 0.18} x2="0" y2={width * 0.18} stroke="#cecece" strokeWidth="1"/>
        </g>;
    }
}

LegendItem.propTypes = {
    item: PropTypes.shape({
        percent: PropTypes.number.isRequired,
        value: PropTypes.number.isRequired,
        label: PropTypes.string.isRequired,
        className: PropTypes.string,
        isEmpty: PropTypes.boolean
    }).isRequired,
    width: PropTypes.number.isRequired,
    totalWidth: PropTypes.number.isRequired,
    onMouseEnter: PropTypes.func.isRequired,
    onClick: PropTypes.func.isRequired,
    index: PropTypes.number,
    opacity: PropTypes.number,
    stroke: PropTypes.string,
    fill: PropTypes.string,
    className: PropTypes.string
};

LegendItem.defaultProps = {
    item: {
        label: 'Default',
        percent: 0,
        value: 0,
        isEmpty: true
    },
    index: 0,
    opacity: 1,
    fill: '#e0e0e0',
    stroke: '#e0e0e0',
    className: 'donutchart-legend-item',
    width: 250,
    totalWidth: 750,
    onMouseEnter: item => item,
    onClick: item => item
};
