//Top Authors widget

import React, { Component } from 'react'
import Slider from "react-slick"
import Spline from './Spline';

const topAuthors = [
   {
      id: 1,
      name: "Natasha Knight",
      avatarSrc:require("Assets/img/user-1.jpg"),
      phone: "+01 2345 67890",
      email: "natasha@example.com",
      address: "E-51 Phase-1 Mohali",
      articles:200,
      followers: 1400,
      likes:580
   },
   {
      id: 2,
      name: "Lisa Roy",
      avatarSrc: require("Assets/img/user-2.jpg"),
      phone: "+01 2345 67890",
      email: "lisa@example.com",
      address: "London United Kingdom",
      articles: 50,
      followers: 400,
      likes: 200
   },
   {
      id: 3,
      name: "Andre Hicks",
      avatarSrc: require("Assets/img/user-3.jpg"),
      phone: "+01 2345 67890",
      email: "hicksandre@example.com",
      address: "778 Nicole Station Suite 903",
      articles: 75,
      followers: 1700,
      likes: 2000
   },
   {
      id: 4,
      name: "Jhon Smith",
      avatarSrc: require("Assets/img/user-4.jpg"),
      phone: "+01 2345 67890",
      email: "jhon@example.com",
      address: "E-51 Phase-1 Mohali",
      articles: 175,
      followers: 1200,
      likes: 1800
   }
]

export default class TopAuthors extends Component {
   render() {
	   
	   let opt = {
				data: [[5, 6, 15]],
				colors: ['#7B43A1'],
				labels: ['Bins'],
				axis: [10, 30, 45, 60]
		}
	   
      const settings = {
         dots: false,
         infinite: true,
         speed: 500,
         slidesToShow: 1,
         slidesToScroll: 1,
         autoplay: false,
      };
      //console.log(asd)
      return (
    		  
         <div>
         <div className="pt-4 rounded-top">
         	<h4 className="title">Bin Retrival Time</h4>
	         <div className="btn-group dayweek" role="group" aria-label="Basic example">
				<button type="button" className="btn btn-light btn-sm active">DAY</button>
				<button type="button" className="btn btn-light btn-sm">WEEK</button>
			</div>
            <Slider {...settings}>
               {topAuthors && topAuthors.map((author, key) => (
                  <div key={author.id} className="author-detail-wrap d-flex justify-content-between flex-column">
                  	<div className="author-avatar overlay-wrap mb-5">
				  	    <div className="avatar-img">
				  	    	<h5>Overall</h5>
                        </div>
                        <div className="authors-info text-center">
                			<Spline opt={opt} />
                		</div>	
                    </div>	
                  </div>
               ))}
            </Slider>
            </div>
         </div>
      )
   }
}
