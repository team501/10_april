
import React, { Component } from 'react';

// api
import api from 'Api';
import CountUp from 'react-countup';
//chart
//chart config


// helpers
import { hexToRgbA } from 'Helpers/helpers';
//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';
import { ProgressBar } from 'react-bootstrap';
import Grid from '@material-ui/core/Grid';

import Spinner from 'Util/Spinner';


class Pbar extends Component {



	render() {
		let inductPercentage = 80 ;
			let lag = 10;
			let success = 10;
			let rem =  100 - lag;
			let successPerc = inductPercentage;
			let pointerPerc = inductPercentage + 2;
			let lagPerc = inductPercentage + 10;
			let timePerc = inductPercentage + 5;
			console.log("widthPerc .... ");
			console.log(lagPerc);
			console.log(timePerc);
			const customWidth = {
				width: inductPercentage+'%'
			}
			const customWidthGreen = {
				width: successPerc+'%'
			}
			const customWdthPntr = {
				width: pointerPerc+'%'
			}
			const customWidthRed = {
				width: lagPerc +'%',
				//color: linear-gradient(to right,  white rem+'%', red lag+'%'),
			}
			const customWidthTime = {
				width: timePerc +'%'
			}
			
			return (

					<RctCollapsibleCard colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full opcontainer" heading="" key="" fullBlock >
						<Grid item xs={12} sm={12}>
							<div className="opProgressbar">
									<div className="customBar station-status-textblack" style={customWdthPntr} >{inductPercentage}%</div>	
									<div className="customBar" style={customWdthPntr} >&#x2BC6;</div>	
									
									{<ProgressBar style={{height: '5px'}} now={inductPercentage} />}
									
							</div>
						</Grid>
		                <Grid item xs={12} sm={12}>
							<div>
									<div className="customBarTime station-status-textblack opgreen" style={customWidthTime} >00:00:00</div>	
									<div className="customBarGreen" style={customWidthGreen} >&nbsp;</div>									
									{<ProgressBar style={{height: '5px'}} now={inductPercentage} />}
									
							</div>
						</Grid>
						 
		     
		        </RctCollapsibleCard>
			);
			
			
		}
		
	}


export default Pbar;

