import React, { Component } from 'react';

import {Link} from 'react-router-dom';

import Pbar from './Pbar.js';

import 'react-circular-progressbar/dist/styles.css';


import Paper from '@material-ui/core/Paper';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
// Import custom examples
import SegmentedArcProgressbar from '../arc/SegmentedArcProgressbar';

class OverallWorkMonitor extends Component {
state = {
        ordersStatus: null,
        zone: "all"
    }
    render(){
	const percentage = 35;
      return(
        <div className="app-horizontal collapsed-sidebar">
        <div className="app-container">
            <div className="rct-page-wrapper">
                <div className="rct-app-content">
                    <div className="app-header">
                      <div className="operation_bg overall-work-monitor">
					  <div class="row row-no-margin">
							<div className="col-sm-10 col-md-10 col-lg-10 col-xl-10 title">Operations</div>
                                        <div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 dropdown">
                                           
                                               <FormControl fullWidth>
                                                <Select
                                                value={this.state.zone}
                                                onChange={this.handleChange}
                                                name="zone"
                                                IconComponent={props => (
                                                    <i {...props} className={`material-icons ${props.className}`}>
                                                      keyboard_arrow_down
                                                    </i>
                                                )}
                                                >
                                                <MenuItem value="all"><em>All Zones</em></MenuItem>
                                                <MenuItem value={10}>Zone 1</MenuItem>
                                                <MenuItem value={20}>Zone 2</MenuItem>
                                                <MenuItem value={30}>Zone 3</MenuItem>
                                                </Select>
                                            </FormControl>
                                            
                                        </div>
										</div>
							<div class="row row-no-margin">
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
								</div>
								<div className="col-sm-5 col-md-5 col-lg-5 col-xl-5 leftAlign"> 
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign opHeadertext"> Total
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign center opHeadertext"> Producity
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign text-nowrap opHeadertext"> Bin Status
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign center opHeadertext"> Others
								</div>
								
								
							</div>
							<Link style={{display: 'block' }} to={{ pathname: `/app/dashboard/gtp/Picking/znlstnDtls`}}>
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle alignLeft"> Picking
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-7 col-md-7 col-lg-7 col-xl-7 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignOthers">
									<div className="station-status-textblack">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							</Link>
							<div className="clearboth"></div>
							<Link style={{display: 'block' }} to={{ pathname: `/app/dashboard/gtp/Consolidation/znlstnDtls`}}>
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle alignLeft"> Consolidation
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-7 col-md-7 col-lg-7 col-xl-7 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 alignOthers">
									<div className="station-status-textblack margin17">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							</Link>
							<div className="clearboth"></div>
							<Link style={{display: 'block' }} to={{ pathname: `/app/dashboard/gtp/Decanting/znlstnDtls`}}>
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle"> Decanting
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-7 col-md-7 col-lg-7 col-xl-7 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign">
									<div className="station-status-textblack margin17">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							</Link>
							<div className="clearboth"></div>
							<Link style={{display: 'block' }} to={{ pathname: `/app/dashboard/gtp/Cycle Count/znlstnDtls`}}>
							<div className="row row-no-margin opration-radius">
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign station-status-textblack text-middle alignLeft"> Cycle Count
								</div>
								<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign"> 
									<div className="row row-no-margin">
									<div className="col-sm-4 col-md-4 col-lg-4 col-xl-4 leftAlign">
										<div className="opcontainersubtext">Progress</div>
										<div className="opsmalltext"><i>(In Units)</i></div>
									<div className="opcontainersubtext">Time</div>
										<div className="opsmalltext"><i>(hh:mm:ss)</i></div>
									</div>
									<div className="col-sm-7 col-md-7 col-lg-7 col-xl-7 leftAlign"> <Pbar/></div>
								
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 leftAlign"> 
									<div className="station-status-textblack margin17">26000</div>
									<div className="station-status-textblack margin28">99:99:99</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2"> 
									<div style={{paddingLeft: '25px'}}>
										<div style={{ width: '80px', height: '80px'}}>
											<SegmentedArcProgressbar percentage={percentage}  segments={20} textColor={"#000000"}/>
											<div className="prodLabel"><b>9999</b>/9999</div>
											<div className="prodSubLabel"><i>(For Hour)</i></div>
										</div>		
									</div>
								</div>
								<div className="col-sm-1 col-md-1 col-lg-1 col-xl-1 alignBinStatus "> 
									<div className="station-status-textblack margin17">9999</div>
									<div className="station-status-activetext">Processed</div>
									<div className="station-status-textblack margin10">999<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Process Rate</div>
								</div>
								<div className="col-sm-2 col-md-2 col-lg-2 col-xl-2 leftAlign">
									<div className="station-status-textblack margin17">999</div>
									<div className="station-status-activetext noWrap">Active Stations</div>
									<div className="station-status-textblack opblack">&#x2BC6;00:00:00<span className="pRateLabel"><i>/Hr</i></span></div>
									<div className="station-status-activetext noWrap">Dwell Time</div>
								</div>								
							</div>
							</Link>
							
							 <Paper key={"completed"} elevation={2} square={true} component={'div'} className="mb-10 m-10 size-10 bg-primary"></Paper>
                                    <span className="paperLabel">Completed</span>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <Paper key={"lagging"} elevation={2} square={true} className="size-10 bg-danger"></Paper>
                                    <Paper key={"leading"} elevation={2} square={true} className="mb-10 m-10 size-10 bg-success"></Paper>
                                    <span className="paperLabel">Time lapse</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                      
      );
    }
  }
export default OverallWorkMonitor;
